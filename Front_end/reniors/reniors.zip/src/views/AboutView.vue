<template>
  <div class="about">
    <h1>확인!!</h1>
  </div>
</template>
