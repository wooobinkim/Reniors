<template>
  <div>

  </div>
</template>
<script>
export default {
  name: 'SignupCompleteView',
  components: {},
  data() {
    return {
      example: '',
    }
  },
  setup() {},
  created() {},
  mounted() {},
  unmounted() {},
  methods: {}
}
</script>