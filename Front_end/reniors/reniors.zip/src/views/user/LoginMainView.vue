<template>
  <div class="list">
    <div class="loginbox">
      <img style="width: 80%" alt="logo" src="@/assets/logo.png" />
      <br />
      <div class="loginmenu">
        <div id="userlogin">
          <router-link :to="{ name: 'LoginUser' }">
            <button class="userbtn">개인 로그인</button>
          </router-link>
        </div>
        <div id="companylogin">
          <router-link :to="{ name: 'LoginCompany' }">
            <button class="companybtn">기업 로그인</button>
          </router-link>
        </div>
      </div>
      <br />
      <p class="proposal">혹시 계정이 없으신가요?</p>
      <router-link class="link" style="color: #ff843e" :to="{ name: 'Signup' }">
        개인 회원가입
      </router-link>
      <router-link
        class="link"
        style="color: #37bf99"
        :to="{ name: 'companyregist' }"
      >
        기업 회원가입
      </router-link>
    </div>
  </div>
</template>
<script>
export default {
  name: "LoginMainView",
  components: {},
  data() {
    return {
      example: "",
    };
  },
  setup() {},
  created() {},
  mounted() {},
  unmounted() {},
  methods: {},
};
</script>

<style scoped>
.list {
  padding-top: 11vh;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.loginbox {
  width: 100%;
  justify-content: center;
  align-items: center;
  margin: 8px 0px;
}

.loginmenu {
  display: flex;
  justify-content: center;
  align-items: center;
}

.loginmenu > div {
  margin: 0px 5px;
}

.userbtn {
  width: auto;
  height: 160px;
  border: solid;
  /* border-color: #FF843E;
  background-color: #FFF5F0; */
  background-color: #ff843e;
  border-radius: 10px;
  color: white;
  font-weight: bold;
  padding: 10px;
  font-size: 20px;
}

.companybtn {
  width: auto;
  height: 160px;
  border: solid;
  /* border-color: #37BF99;
  background-color: #ECFFFA; */
  background-color: #37bf99;
  border-radius: 10px;
  color: white;
  font-weight: bold;
  padding: 10px;
  font-size: 20px;
}

.proposal {
  color: #6d6d6d;
  font-size: 16px;
}

.link {
  display: inline;
  margin: 8px;
  /* font-family: 'Inter'; */
  font-style: normal;
  /* font-weight: 600; */
  font-size: 14px;
  line-height: 17px;
  color: #6d6d6d;
  text-decoration: none;
  font-weight: bold;
  font-size: 16px;
}
</style>
