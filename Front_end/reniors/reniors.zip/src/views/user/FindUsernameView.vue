<template>
	<div>
		<h1>아이디 찾기</h1>
	</div>
</template>
<script>
export default {
	name: 'FindUsernameView',
	components: {},
	data() {
		return {
			example: '',
		}
	},
	setup() {},
	created() {},
	mounted() {},
	unmounted() {},
	methods: {}
}
</script>