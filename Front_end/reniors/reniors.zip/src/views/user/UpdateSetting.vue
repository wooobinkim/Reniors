<template>
  <div>
    <prefer-setting action="update"></prefer-setting>

  </div>
</template>
<script>
import PreferSetting from '@/components/user/PreferSetting.vue'
export default {
  components: { PreferSetting },
  data() {
    return {
      example: '',
    }
  },
  setup() {},
  created() {},
  mounted() {},
  unmounted() {},
  methods: {}
}
</script>