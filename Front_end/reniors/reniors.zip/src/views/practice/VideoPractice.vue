<template>
  <div>

  </div>
</template>
<script>

export default{ 
    name:'VideoPractice',
    components:{},
    data(){
        return{
            sampleData:''
        };
    },
    setup(){},
    created(){},
    mounted(){},
    unmounted(){},
    methods:{}
}
</script>