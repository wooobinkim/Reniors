<template>
  <div id="home">
    <company-home></company-home>
  </div>
</template>

<script>
import CompanyHome from "@/components/home/CompanyHome.vue";
export default {
  components: {
    CompanyHome,
  },
  
};
</script>

<style></style>
