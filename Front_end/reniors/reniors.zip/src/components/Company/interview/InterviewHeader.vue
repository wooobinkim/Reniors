<template>
  <div>
    <span>면접일정 | </span>
    <span @click="evalpage()">평가관리</span>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
