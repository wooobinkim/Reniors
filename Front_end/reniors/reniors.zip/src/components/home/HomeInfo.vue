<template>
  <div class="home-info">
    <p>정보 및 심리검사 배너</p>
  </div>
</template>

<script>
export default {
  name: 'HomeInfo',
}
</script>

<style>
.home-info {
  background-color: var(--color-black-4);
  border-radius: 0.3rem;
  margin: 5px;
  height: 200px;
}
</style>