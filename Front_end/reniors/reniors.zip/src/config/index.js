const API_BASE_URL = "https://i7b307.p.ssafy.io/api";

export { API_BASE_URL, };