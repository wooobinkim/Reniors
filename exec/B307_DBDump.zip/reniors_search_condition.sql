-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `search_condition`
--

DROP TABLE IF EXISTS `search_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_condition` (
  `search_condition_id` bigint NOT NULL,
  `job_parent_category_id` bigint DEFAULT NULL,
  `last_edu` varchar(255) DEFAULT NULL,
  `min_career` int NOT NULL,
  `min_salary` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `type_employment` varchar(255) DEFAULT NULL,
  `working_day` int NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`search_condition_id`),
  KEY `FK78hax3kdmo3ugdaky3tb7i89m` (`user_id`),
  CONSTRAINT `FK78hax3kdmo3ugdaky3tb7i89m` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_condition`
--

LOCK TABLES `search_condition` WRITE;
/*!40000 ALTER TABLE `search_condition` DISABLE KEYS */;
INSERT INTO `search_condition` VALUES (18,NULL,NULL,0,0,'asd','정규직',0,1),(28,NULL,NULL,0,0,'안녕',NULL,0,17),(75,NULL,NULL,0,0,'맞춤1','정규직',0,33),(76,NULL,NULL,1,3,'맞춤2','정규직',6,33),(78,NULL,NULL,0,0,'맞춤3','파견직',0,33),(79,NULL,NULL,0,0,'맞춤4',NULL,0,33),(102,16,'대학교졸업_4년제',1,2,'ㅋㅋ','인턴',1,1),(127,2,NULL,0,3000,'kiki',NULL,0,14),(133,1,'학력무관',0,1,'김우빈 맞춤공고1','정규직',5,42),(198,1,NULL,0,0,'내 맞춤공고1',NULL,0,9),(201,1,NULL,0,0,'나의 맞춤공고1',NULL,0,53),(203,1,'학력무관',0,0,'나의 맞춤공고2','인턴',5,53),(205,1,'고등학교졸업',0,30000,'나의 맞춤공고3','인턴',1,53);
/*!40000 ALTER TABLE `search_condition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:29
