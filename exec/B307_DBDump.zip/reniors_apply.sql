-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apply`
--

DROP TABLE IF EXISTS `apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apply` (
  `apply_id` bigint NOT NULL,
  `interview_date` datetime DEFAULT NULL,
  `job_opening_process` varchar(255) NOT NULL,
  `job_opening_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`apply_id`),
  KEY `FKak7k4vibxe9c7evtq8ob3usx4` (`job_opening_id`),
  KEY `FKfp0eaj9wr8aj6v5qlfd9luxw1` (`user_id`),
  CONSTRAINT `FKak7k4vibxe9c7evtq8ob3usx4` FOREIGN KEY (`job_opening_id`) REFERENCES `job_opening` (`job_opening_id`),
  CONSTRAINT `FKfp0eaj9wr8aj6v5qlfd9luxw1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apply`
--

LOCK TABLES `apply` WRITE;
/*!40000 ALTER TABLE `apply` DISABLE KEYS */;
INSERT INTO `apply` VALUES (1,NULL,'최종합격',1,1,NULL),(2,NULL,'최종합격',1,2,NULL),(3,NULL,'최종합격',1,3,NULL),(4,NULL,'최종합격',1,4,NULL),(5,NULL,'최종합격',1,5,NULL),(6,NULL,'최종합격',1,6,NULL),(13,NULL,'최종합격',1,14,NULL),(19,NULL,'최종합격',1,17,NULL),(20,NULL,'서류불합격',3,17,NULL),(21,NULL,'최종합격',8,14,NULL),(26,NULL,'최종합격',3,9,NULL),(27,NULL,'최종합격',4,9,NULL),(33,NULL,'최종합격',4,1,NULL),(34,NULL,'최종합격',8,9,NULL),(36,NULL,'최종합격',8,3,NULL),(37,NULL,'최종합격',1,15,NULL),(38,NULL,'최종합격',3,15,NULL),(39,NULL,'서류심사중',2,15,NULL),(40,NULL,'최종합격',1,15,NULL),(42,NULL,'최종합격',1,29,NULL),(81,NULL,'서류불합격',3,34,NULL),(82,NULL,'면접불합격',7,15,NULL),(83,NULL,'최종합격',5,14,NULL),(88,'2022-08-21 23:52:00','면접',9,15,'InterviewSession9'),(94,NULL,'최종합격',7,1,NULL),(95,NULL,'최종합격',3,1,NULL),(96,NULL,'서류심사중',5,1,NULL),(106,NULL,'면접심사중',9,29,NULL),(108,NULL,'서류심사중',2,1,NULL),(109,NULL,'최종합격',8,1,NULL),(110,NULL,'최종합격',8,36,NULL),(111,NULL,'최종합격',7,36,NULL),(112,NULL,'최종합격',1,36,NULL),(113,NULL,'최종합격',3,36,NULL),(114,NULL,'서류심사중',2,36,NULL),(115,NULL,'최종합격',4,36,NULL),(116,NULL,'서류심사중',5,36,NULL),(117,NULL,'최종합격',5,9,NULL),(118,NULL,'최종합격',7,9,NULL),(119,NULL,'서류심사중',6,9,NULL),(120,NULL,'서류심사중',2,14,NULL),(121,NULL,'최종합격',3,14,NULL),(122,NULL,'면접심사중',9,14,NULL),(123,NULL,'최종합격',1,42,NULL),(124,NULL,'최종합격',3,42,NULL),(125,NULL,'서류심사중',2,42,NULL),(126,NULL,'서류심사중',7,42,NULL),(132,NULL,'면접심사중',32,42,NULL),(146,'2022-08-18 10:40:00','면접',4,29,'InterviewSession4'),(152,NULL,'면접불합격',17,14,NULL),(157,NULL,'면접심사중',13,14,NULL),(167,NULL,'면접심사중',23,14,NULL),(168,NULL,'면접심사중',13,53,NULL),(169,NULL,'최종합격',17,53,NULL),(173,NULL,'면접심사중',23,53,NULL),(174,NULL,'서류심사중',1,53,NULL),(182,NULL,'서류불합격',17,15,NULL),(183,NULL,'서류심사중',18,9,NULL),(184,NULL,'서류심사중',1,9,NULL),(188,NULL,'서류심사중',9,9,NULL),(200,'2022-08-19 06:28:33','면접',17,53,'InterviewSession17'),(207,'2022-08-19 07:49:16','면접',33,14,'InterviewSession33');
/*!40000 ALTER TABLE `apply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:29
