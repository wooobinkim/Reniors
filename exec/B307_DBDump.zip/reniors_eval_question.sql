-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eval_question`
--

DROP TABLE IF EXISTS `eval_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eval_question` (
  `eval_question_id` bigint NOT NULL,
  `contents` varchar(500) NOT NULL,
  `job_opening_id` bigint DEFAULT NULL,
  PRIMARY KEY (`eval_question_id`),
  KEY `FKa6mns06h4nutj84y9tjhxs8cf` (`job_opening_id`),
  CONSTRAINT `FKa6mns06h4nutj84y9tjhxs8cf` FOREIGN KEY (`job_opening_id`) REFERENCES `job_opening` (`job_opening_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eval_question`
--

LOCK TABLES `eval_question` WRITE;
/*!40000 ALTER TABLE `eval_question` DISABLE KEYS */;
INSERT INTO `eval_question` VALUES (25,'잘하는쥐~~',1),(34,'잘생겼는지~',1),(35,'잘생김?',8),(46,'zz',4),(50,'유머감각이 있는지',1),(59,'gd',3),(61,'gd',3),(67,'gdgd',4),(68,'gdgdgd',4),(69,'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ',4),(70,'ㅋㅋ',4),(83,'123',1),(84,'456',1),(85,'789',1),(87,'마케팅 능력이 출중한가?',32),(90,'키키키키키',9),(142,'친화력이 좋은가',32),(145,'자신의 장점은?',8),(147,'착한쥐~~',1),(148,'똑똑한쥐~~',1),(153,'자신의 장점은 무엇인가?',13),(154,'협업을 할 때 중요하게 생각하는 부분은?',13),(155,'팀원 간의 갈등을 해결하는 나만의 방법은?',13),(156,'최근에 관심을 가지게 된 IT 관련 이슈는?',13),(158,'자신에 대한 어필을 할 때의 자신감',13),(165,'자신감이 있는지!',23),(166,'얼마나 성실한지!',23);
/*!40000 ALTER TABLE `eval_question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:28
