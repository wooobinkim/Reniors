-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `notification_id` bigint NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `is_read` varchar(255) NOT NULL,
  `job_opening_process` varchar(255) NOT NULL,
  `apply_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `FK3fm2p845qihqgk9jidnsqmqk3` (`apply_id`),
  KEY `FKb0yvoep4h4k92ipon31wmdf7e` (`user_id`),
  CONSTRAINT `FK3fm2p845qihqgk9jidnsqmqk3` FOREIGN KEY (`apply_id`) REFERENCES `apply` (`apply_id`),
  CONSTRAINT `FKb0yvoep4h4k92ipon31wmdf7e` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (2,'2022-08-15 17:46:41','NOT_READ','서류불합격',20,17),(4,'2022-08-17 00:52:23','READ','서류불합격',33,1),(5,'2022-08-17 08:59:08','NOT_READ','서류심사중',106,29),(9,'2022-08-17 17:57:39','NOT_READ','면접',82,15),(17,'2022-08-17 20:28:10','NOT_READ','면접불합격',82,15),(18,'2022-08-17 20:28:10','READ','최종합격',118,9),(20,'2022-08-17 20:44:56','READ','면접',112,36),(21,'2022-08-17 20:45:47','NOT_READ','최종합격',112,36),(22,'2022-08-17 20:48:13','NOT_READ','면접',115,36),(23,'2022-08-17 20:48:34','NOT_READ','최종합격',115,36),(24,'2022-08-17 20:48:34','NOT_READ','면접불합격',33,1),(26,'2022-08-17 20:57:50','READ','최종합격',123,42),(28,'2022-08-17 21:34:54','NOT_READ','면접불합격',38,15),(29,'2022-08-17 21:34:54','NOT_READ','최종합격',113,36),(32,'2022-08-18 13:59:24','NOT_READ','서류불합격',132,42),(33,'2022-08-18 17:27:40','NOT_READ','최종합격',19,17),(34,'2022-08-18 17:27:40','NOT_READ','최종합격',40,15),(35,'2022-08-18 17:43:21','NOT_READ','최종합격',42,29),(36,'2022-08-18 17:43:42','NOT_READ','최종합격',38,15),(37,'2022-08-18 17:43:42','NOT_READ','면접불합격',124,42),(38,'2022-08-18 17:43:42','READ','최종합격',121,14),(39,'2022-08-18 20:45:56','NOT_READ','최종합격',124,42),(40,'2022-08-18 20:48:01','NOT_READ','최종합격',36,3),(41,'2022-08-18 20:48:01','READ','면접불합격',21,14),(42,'2022-08-18 20:49:44','NOT_READ','최종합격',33,1),(43,'2022-08-18 20:54:50','READ','최종합격',83,14),(44,'2022-08-18 20:55:02','NOT_READ','최종합격',21,14),(45,'2022-08-18 21:02:54','NOT_READ','면접',109,1),(46,'2022-08-18 21:03:07','NOT_READ','최종합격',109,1),(47,'2022-08-18 21:37:33','NOT_READ','면접',146,29),(48,'2022-08-18 23:04:20','NOT_READ','면접심사중',122,14),(49,'2022-08-18 23:33:37','NOT_READ','면접심사중',106,29),(50,'2022-08-18 23:33:45','NOT_READ','면접심사중',106,29),(51,'2022-08-19 01:11:32','READ','면접',152,14),(52,'2022-08-19 01:28:55','NOT_READ','면접',157,14),(53,'2022-08-19 01:35:04','NOT_READ','면접심사중',157,14),(55,'2022-08-19 01:46:01','NOT_READ','면접',167,14),(56,'2022-08-19 01:51:30','NOT_READ','면접심사중',167,14),(59,'2022-08-19 02:05:16','NOT_READ','서류불합격',173,53),(60,'2022-08-19 02:05:55','NOT_READ','면접',173,53),(61,'2022-08-19 04:51:14','NOT_READ','면접심사중',169,53),(63,'2022-08-19 04:54:37','NOT_READ','면접불합격',152,14),(64,'2022-08-19 06:28:32','NOT_READ','면접',200,53),(65,'2022-08-19 06:28:32','NOT_READ','서류불합격',182,15),(66,'2022-08-19 06:30:48','NOT_READ','면접심사중',173,53),(67,'2022-08-19 07:49:16','NOT_READ','면접',207,14);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:33
