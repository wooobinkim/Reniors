-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `board_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `contents` text,
  `title` varchar(255) DEFAULT NULL,
  `views` int NOT NULL,
  `job_parent_category_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`board_id`),
  KEY `FKik8lxcwc0ak56serorxn8v4w` (`job_parent_category_id`),
  KEY `FKfyf1fchnby6hndhlfaidier1r` (`user_id`),
  CONSTRAINT `FKfyf1fchnby6hndhlfaidier1r` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKik8lxcwc0ak56serorxn8v4w` FOREIGN KEY (`job_parent_category_id`) REFERENCES `job_parent_category` (`job_parent_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,'2022-08-15 17:42:47','2022-08-19 05:22:19','반갑습니다','안녕하세요',68,1,32),(2,'2022-08-15 17:42:58','2022-08-15 17:42:58','글을 적었습니다','총무법무사무에',2,5,32),(3,'2022-08-15 17:44:06','2022-08-19 05:14:52','글을 적었습니다','마케팅홍보조사에',36,1,32),(4,'2022-08-15 17:44:18','2022-08-15 17:44:18','글을 적습니다','마케팅 홍보 조사에',2,21,32),(5,'2022-08-15 17:44:32','2022-08-15 17:44:32','그렇습니다','시연이 필요합니다',2,20,32),(6,'2022-08-16 16:44:28','2022-08-17 09:05:31','test','test',44,1,1),(7,'2022-08-16 20:04:22','2022-08-19 03:36:39','슈정','안녕하세요 가입인사드립니다',39,1,21),(8,'2022-08-16 20:05:01','2022-08-16 23:28:19','ㅎㅇ','ㅎㅇ',5,2,21),(9,'2022-08-17 04:20:12','2022-08-18 23:33:32','아현아현','아현',14,1,14);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:32
