-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question` (
  `question_id` bigint NOT NULL AUTO_INCREMENT,
  `question` varchar(1000) NOT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (1,'경력단절 기간이 긴데, 그동안 무엇을 하셨나요?'),(2,'다른 직원보다 나이가 많으신데 조직에 잘 적응할 수 있을까요?'),(3,'연세가 있으신데 일을 하시기에 건강은 괜찮으신가요?'),(4,'젊은 동료들과 의견 충돌이 나면 어떻게 해결하실 건가요?'),(5,'필요로 하는 경력이 짧으신데 근무하시기 괜찮을까요?'),(6,'자기소개'),(7,'지원동기'),(8,'자신의 단점은?'),(9,'최근에 읽은 책은'),(10,'존경하는 인물은'),(11,'상사와 의견이 맞지 않다면 어떻게 할 것인가'),(12,'상사와의 갈등을 어떻게 풀 것인가'),(13,'상사의 부정을 알게 된다면 어떻게 행동할 것인가'),(14,'생활신조에 대해서/좌우명은'),(15,'창의성을 발휘한 적은'),(16,'공백 기간이 긴 이유는'),(17,'동료직원과 분쟁이 생일 경우 어떻게 대처할 것인가'),(18,'회사의 장단점을 설명하라'),(19,'야근을 할 의사가 있는가'),(20,'타회사와 동시 합격 시 어떻게 할 것인가'),(21,'스트레스가 많은 직장일 수 있다. 당신의 스트레스 해소법은?'),(22,'면접을 준비하면서 회사나 직무에 대해서 궁금했던 사항이 있는가?'),(23,'자신이 생각하는 리더란?'),(24,'마지막 한마디'),(25,'왜 우리 회사 입니까?'),(26,'성공 사례 또는 실패 사례'),(27,'자신의 주요 경력과 경험 위주로 포트폴리오를 소개한다면?'),(28,'본인이 이 회사, 해당 직무에 적합한 인재인 이유는 무엇이라 생각합니까?'),(29,'현재 직무에서 가장 중요한 역량이 무엇이라고 생각하는가'),(30,'조직의 다양한 문제 해결에 있어 가장 중요하고, 먼저 해야 할 일은 무엇인가?'),(31,'팀을 이끄는 데 있어 자신만의 강점, 특징, 차별점은 무엇인가? 상사와 이견을 조율했던 경험이 있는가?'),(32,'본인의 조직 내 커리어 목표 혹은 커리어 최종 목표는?'),(33,'취미가 무엇인가'),(34,'나이 어린 선배와 잘 지낼 수 있는가'),(35,'입사포부 면접 예상 질문'),(36,'야근과 주말근무가 있다면 어떻게 할 것인가'),(37,'상사의 지시가 부당하면 어떻게 할 것인가');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:25
