-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `company_id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(100) DEFAULT NULL,
  `baseurl` varchar(255) DEFAULT NULL,
  `company_app_id` varchar(100) DEFAULT NULL,
  `company_app_pwd` varchar(200) DEFAULT NULL,
  `company_num` varchar(100) DEFAULT NULL,
  `company_phone` varchar(30) DEFAULT NULL,
  `company_profile` varchar(255) DEFAULT NULL,
  `company_url` varchar(100) DEFAULT NULL,
  `established_at` varchar(50) DEFAULT NULL,
  `extra_address` varchar(255) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `representative` varchar(50) DEFAULT NULL,
  `representative_phone` varchar(30) DEFAULT NULL,
  `type_company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (1,'부산 중구 기주동 10-2','https://reniors.s3.ap-northeast-2.amazonaws.com/','company','$2a$10$o3HGt5b/QplhvaDVVRJOgeNqBdviEfW1pgqCd7qvk1GOio39RNOrC','111-222-7643','010-7581-8725','company/6f8fe319-e0dd-4213-a2d4-ab5e523c067f.png','www.nabber.com','1988','거제빌딩 3층','큐브코퍼','string','010-7411-4520','강소기업'),(6,'서울시 구로구 김창동 1055-453','https://reniors.s3.ap-northeast-2.amazonaws.com/','jungkim@jk.com','$2a$10$Yqf0jnL6RS604Lql1iRH1.3H2/89M.ONQSHSpb.9AQAQKowABqFFa','123135-789745','02-7415-5785','company/e548e2f4-c1cc-40c2-bcbd-4b9be70072cc.png','https://www.ssafy.com/ksp/jsp/swp/swpMain.jsp','1988','203동 102호','(주)정김',NULL,'010-7741-8954','중소기업'),(17,'부산광역시 중구 추아동 1-23','https://reniors.s3.ap-northeast-2.amazonaws.com/','leaf@lf.com','$2a$10$yeSJIkHcZFFtZ3uIQXrYD.Zbs3bzAAiU.tMbg3QR4nxF4UJ/cRS7m','789451-8974511','032-984-7841','company/1e10c98f-c2b5-4c79-a018-bb4b7bce119a.png','www.daum.net','2015','남신빌딩','리프주식회사',NULL,'010-1242-5435','강소기업'),(18,'경기도 부천시 구가동 24-53','https://reniors.s3.ap-northeast-2.amazonaws.com/','atech@at.com','$2a$10$QFKaPLEFQdM8wLS2NuT1suhNap5QMBggxRpBQ3cyjSqBuiUgscM5a','123498-7874514','02-7955-8521','company/acef76b8-7a2c-405c-b256-4c03e96bb548.png','www.google.com','2016','203동 102호','에이테크',NULL,'010-8751-9872','중견기업'),(19,'대전광역시 유성구 덕명동 60-1','https://reniors.s3.ap-northeast-2.amazonaws.com/','kei@k.com','$2a$10$ZCeUn/qp3Xzg6wq1AQ18.eAfRxVlHxb1lPTjN2VWr/l21VDW6p76K','979451-8795125','031-751-8910','company/adb66c7e-16c2-4082-9587-72d5d1af062a.png','www.nate.com','2000','102','(주)케이',NULL,'010-9751-7852','대기업'),(20,'서울특별시 강남구 한남동 231-2','https://reniors.s3.ap-northeast-2.amazonaws.com/','gab@g.com','$2a$10$SAWa5Fu7ssLFF2fQwuJVXu4hnzQHf2TZSaqGe43I7GNYSZ5igCoUS','845110-8921565','02-9633-8740','company/cf5abb3c-fb64-4325-b23f-ed2fdfd205f3.png','www.nexon.com','1988','213동 102호','갑 엔터테인먼트',NULL,'010-8620-8711','중견기업'),(22,'LGLG','https://reniors.s3.ap-northeast-2.amazonaws.com/','lg@lg','$2a$10$mqNRJOM5qXCypoenVz1zcudrXlHW6deagasDAOG/H398bJUTQg.F2','7124-9348-1293','01084839250','company/companyBaseProfile.png','https://lg.com','0000','203동 122호','LG',NULL,'01012345123','대기업'),(23,'경기도 시흥시 비법동 94-2','https://reniors.s3.ap-northeast-2.amazonaws.com/','flower@f.com','$2a$10$FwOe80mkBJR.U.sqMP/k1ewffEU2OLQeK/dBm67WfNpHuLzS4Anty','111-222-4444','010-9721-9753','company/6841d0ae-c50d-4426-95ff-71b5ccbb047a.PNG','www.toss.com','1925','3동 102호','(주)플라워',NULL,'010-8451-9756','대기업'),(25,'수원시 인계동','https://reniors.s3.ap-northeast-2.amazonaws.com/','Rhcakdmf@R.com','$2a$10$s3sgjvGlShxg0/RoBVgbfOCvyiCCC/huW47P67WBoRKnzfbiwNfpC','37327-124-3214','01094349901','company/f62b7452-4b02-4b79-bd82-553f74be7f20.png','https://flowertown.ssafy.io','2008',NULL,'꽃마을',NULL,'0105435388','중견기업'),(26,'부산광역시 서구','https://reniors.s3.ap-northeast-2.amazonaws.com/','qkqkfldks@b.com','$2a$10$7KjqKLgXCI5x9dL.Z./gyeOTqySTGahhzlCcK/79Pr0kuM/Lzhzkm','12515-2323-435','01044253332','company/273bb8ca-09fd-4c6c-b0d4-328693b6569b.png','https://barbarians.cafe.io','2018',NULL,'카페 바바리안',NULL,'01044253332','중소기업'),(27,'광주광역시 월곡동','https://reniors.s3.ap-northeast-2.amazonaws.com/','dkfka@d.com','$2a$10$uwTPDo7LSVSA/wX0H6d4s.8DMBGLaxQJEC7vjYG0qbjJMguGGs1qu','59084-412-5325','01094124823','company/0bda51e7-d670-4442-8177-3e5089496474.png','https://aram.back.io','2000',NULL,'아람 은행',NULL,'01054346899','강소기업');
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:30
