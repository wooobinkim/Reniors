-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recording`
--

DROP TABLE IF EXISTS `recording`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recording` (
  `recording_id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `recordurl` varchar(255) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `video_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`recording_id`),
  KEY `FKqixwobt4tcvlq4skfxwehimc2` (`user_id`),
  CONSTRAINT `FKqixwobt4tcvlq4skfxwehimc2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recording`
--

LOCK TABLES `recording` WRITE;
/*!40000 ALTER TABLE `recording` DISABLE KEYS */;
INSERT INTO `recording` VALUES (27,'2022-08-15 01:24:05','2022-08-15 01:24:05','test','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session1/Session1.mp4',1,'8TgN1-WrQwODQhaZFIaMEw'),(28,'2022-08-15 01:37:05','2022-08-15 01:37:05','dnqls','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session1~1/Session1~1.mp4',1,'P5yMPdwgSPqXTk_5aV9Ltw'),(29,'2022-08-15 01:38:26','2022-08-15 01:38:26','test1','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session1~2/Session1~2.mp4',1,'F7XpsUEFRsOB2CN8PNBiAA'),(41,'2022-08-18 15:51:01','2022-08-18 15:51:01','상사참교육','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session42~13/Session42~13.mp4',42,'YWqIbb3VRZCsVlJvWxYFJg'),(42,'2022-08-18 20:39:03','2022-08-18 20:39:04','완료','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session50/Session50.mp4',50,'eKqUL_lbThGU04x5dhx-Rw'),(43,'2022-08-18 20:39:39','2022-08-18 20:39:39','이저','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session1~4/Session1~4.mp4',1,'CP6afo77RimwevYxi-7d0w'),(44,'2022-08-18 20:40:31','2022-08-18 20:40:31','에벱','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session1~5/Session1~5.mp4',1,'3zI7EtZ_S5myzPF1qxiQeA'),(45,'2022-08-18 21:25:19','2022-08-18 21:25:21','녹화','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session14/Session14.mp4',14,'LD7p6h17Sr-EWVPQH8iibA'),(46,'2022-08-18 21:25:19','2022-08-18 21:25:21','녹화','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session14/Session14.mp4',14,'EeWD8kdOQKWNc0JIL7-fCQ'),(47,'2022-08-18 21:58:25','2022-08-18 21:58:25','아바다','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session9/Session9.mp4',9,NULL),(48,'2022-08-18 22:07:41','2022-08-18 22:07:42','미친소리','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session36/Session36.mp4',36,'2ttNcsB5RlOJnmSSd-_XvA'),(49,'2022-08-19 04:08:40','2022-08-19 04:08:40','에바임','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session36~1/Session36~1.mp4',36,'WltzVc1YRBaxwGDFvHvZEw'),(50,'2022-08-19 04:16:23','2022-08-19 04:16:23','꽁먹','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session36~2/Session36~2.mp4',36,'KI_z8s5QTlSVQGof-qRTmw'),(51,'2022-08-19 04:34:55','2022-08-19 04:34:55','화상연습 1','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session53~1/Session53~1.mp4',53,'_dpoHHApR3iePNe21jipSQ'),(52,'2022-08-19 05:16:11','2022-08-19 05:16:12','면접 연습 1','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session9~1/Session9~1.mp4',9,'HOM3FqecSQqBEKqlOAx2Tg'),(53,'2022-08-19 05:17:32','2022-08-19 05:17:33','면접 연습','https://i7b307openvidu.ssafy.io:4443/openvidu/recordings/Session9~2/Session9~2.mp4',9,'b4QrIwEKR2yVD8MM6bpUBg');
/*!40000 ALTER TABLE `recording` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:31
