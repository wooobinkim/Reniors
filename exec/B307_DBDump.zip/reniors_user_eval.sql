-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: i7b307.p.ssafy.io    Database: reniors
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_eval`
--

DROP TABLE IF EXISTS `user_eval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_eval` (
  `user_eval_id` bigint NOT NULL,
  `memo` varchar(1000) DEFAULT NULL,
  `score` varchar(100) DEFAULT NULL,
  `eval_question_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`user_eval_id`),
  KEY `FKymb4soct1cvvt4tvs0dmjmuk` (`eval_question_id`),
  KEY `FKfj8fhk9lxilsdg7cxnwibwfb3` (`user_id`),
  CONSTRAINT `FKfj8fhk9lxilsdg7cxnwibwfb3` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKymb4soct1cvvt4tvs0dmjmuk` FOREIGN KEY (`eval_question_id`) REFERENCES `eval_question` (`eval_question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_eval`
--

LOCK TABLES `user_eval` WRITE;
/*!40000 ALTER TABLE `user_eval` DISABLE KEYS */;
INSERT INTO `user_eval` VALUES (1,'잘했음','10',25,14),(2,'넹','10',35,9),(36,'ㅋㅋ','10',35,3),(143,'아뇨','5',87,42),(144,'개별로','2',142,42),(149,'아웃','0',90,29),(150,'아웃','0',90,29),(151,'아웃','0',90,29),(159,'adasdas','10',153,14),(160,'좋다','10',154,14),(161,'굳','10',155,14),(162,'좋네요','10',156,14),(163,'좋네요ㅁㄴㅇㅁㄴㅇㅁㄴㅇㅁㄴㄹㄴ와넝헌아후ㅏㄴ어ㅝㄴ아훠ㅏㅝ아ㅝㅏ눠ㅏㄴ우허ㅏ누어훈어ㅏㅓㄴ아ㅝㅏㅍ훈어ㅏㅜㄴ어ㅏㅜㅏㄴ어풔ㅏㄴ워ㅏㄴ워ㅏㄴㅇ풔ㅏㄴㅇ풔ㅏㄴ워ㅏㄴ워ㅏㄴ우ㅏㄴ어ㅝㅏㄴ우ㅏㄴ어ㅜㅇ너ㅏㅜㄴ아ㅓㅜㄴ어ㅏㄹㄴ어ㅏㅜ러ㅏㄴㅇ루ㅏㄴ어룬어ㅏ뤄ㅏ','10',156,14),(164,'베리 나이스','9',158,14),(170,'123ㅂㅈㄴㄷ','12',165,14),(171,'ㅁㄴㅇㅁㄴㅇ','12',166,14),(172,'ㅁㄴㅇ','10',153,53);
/*!40000 ALTER TABLE `user_eval` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  7:50:33
